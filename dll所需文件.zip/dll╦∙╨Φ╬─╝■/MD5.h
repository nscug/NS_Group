#ifndef MD5_H_INCLUDED
#define MD5_H_INCLUDED

void MD5IN(unsigned char encrypt[], unsigned char result[]);

#endif // MD5_H_INCLUDED
